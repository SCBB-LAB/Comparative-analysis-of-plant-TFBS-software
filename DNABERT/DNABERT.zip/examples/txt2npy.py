import numpy as np
import sys

y = np.loadtxt(sys.argv[1]+".txt")

z=np.save(sys.argv[1]+".npy", y)

