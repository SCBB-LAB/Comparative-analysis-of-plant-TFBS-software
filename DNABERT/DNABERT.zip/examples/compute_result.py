import argparse
import numpy as np
import csv
from copy import deepcopy
from sklearn.metrics import matthews_corrcoef, confusion_matrix, f1_score, accuracy_score,roc_auc_score
def evaluate(args):
    predict_results = np.load(args.pred_path) 
    labels = np.load(args.label_path)
    labels = list(labels.astype(int))
    auroc = roc_auc_score(labels, predict_results)
    pred_labels=np.array(predict_results)
    pred_labels[pred_labels>=0.5]=1
    pred_labels[pred_labels<0.5]=0
    acc=accuracy_score(labels,pred_labels)
    f1 = f1_score(labels,pred_labels)
    mcc = matthews_corrcoef(labels,pred_labels)
    tn, fp, fn, tp = confusion_matrix(labels,pred_labels).ravel()
    specificity = tn / (tn+fp)  
    sensitivity = tp / (tp+fn)
    print("number of examples: " + str(len(labels)))
    print("number of positive examples: " + str(sum(labels)))
    print("number of negative examples: " + str(len(labels)-sum(labels)))
    print("tn:" + "\t"+str(tn))
    print("fp:" + "\t"+str(fp))
    print("fn:" + "\t"+str(fn))
    print("tp:" + "\t"+str(tp))
    print("accuracy: " + "\t"+str(acc))
    print("sp",specificity)
    print("sn",sensitivity)
    print("f1: ", str(f1))
    print("mcc: " + str(mcc))
    print("auc: " + str(auroc))
    f3 = open("examples/"+args.name+"/"+args.name+"_result.txt",'w')
    f3.writelines("TP"+"\t"+"TN"+"\t"+"FN"+"\t"+"FP"+"\t"+"TPR"+"\t"+"TNR"+"\t"+"ACC"+"\t"+"F1"+"\t"+"MCC"+"\t"+"auc"+"\n")
    f3.writelines(str(tp)+"\t"+str(tn)+"\t"+str(fn)+"\t"+str(fp)+"\t"+str(sensitivity)+"\t"+str(specificity)+"\t"+str(acc)+"\t"+str(f1)+"\t"+str(mcc)+"\t"+str(auroc)+"\n")
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--name",
        default=None,
        type=str,
        help="The path of the predicted result",
    )
    parser.add_argument(
        "--pred_path",
        default=None,
        type=str,
        help="The path of the predicted result",
    )
    parser.add_argument(
        "--label_path",
        default=None,
        type=str,
        help="The path of the label",
    )
    parser.add_argument(
        "--task",
        default="eval",
        type=str,
        help="Which task to compute result",
    )
    args = parser.parse_args()

    if args.task == "eval":
        evaluate(args)
    else:
        raise ValueError() 
        
if __name__ == "__main__":
    main()


