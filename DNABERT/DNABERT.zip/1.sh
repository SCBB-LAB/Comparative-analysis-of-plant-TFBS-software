python3.8 examples/run_finetune.py     --model_type dna     --tokenizer_name=dna$KMER     --model_name_or_path $MODEL_PATH     --task_name dnaprom     --do_train     --do_eval     --data_dir $DATA_PATH     --max_seq_length 200     --per_gpu_eval_batch_size=32       --per_gpu_train_batch_size=32       --num_train_epochs 5     --output_dir $OUTPUT_PATH     --evaluate_during_training     --logging_steps 100     --save_steps 4000     --warmup_percent 0.1     --hidden_dropout_prob 0.1     --overwrite_output     --weight_decay 0.001     --n_process 8 --learning_rate 0.0005

python3.8 examples/run_finetune.py --model_type dna --tokenizer_name=dna6 --model_name_or_path examples/ABF2/ --task_name dnaprom --do_predict --data_dir examples/ABF2/ --max_seq_length 200 --per_gpu_pred_batch_size=128 --output_dir examples/ABF2/ --predict_dir examples/ABF2/ --n_process 48

cut -f2 examples/ABF2/dev.tsv | sed 1d > examples/ABF2/label.txt 
python3 examples/txt2npy.py examples/ABF2/label
python3 examples/compute_result.py --pred_path examples/ABF2/pred_results.npy --label_path examples/ABF2/label.npy --name ABF2
