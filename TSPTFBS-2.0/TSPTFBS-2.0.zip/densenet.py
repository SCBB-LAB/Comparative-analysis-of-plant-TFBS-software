import numpy as np
import pandas as pd
from pandas import DataFrame,Series
import re 
import time
import os, sys

import math
from sklearn.metrics import roc_curve, auc, average_precision_score
from sklearn.metrics import accuracy_score,roc_auc_score
from sklearn.model_selection import StratifiedKFold,train_test_split
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import models
from tensorflow.keras.layers import Input,add,Dense,concatenate,Flatten,Conv1D,AveragePooling1D,Dropout,Reshape,multiply,BatchNormalization
from tensorflow.keras.models import Model
from tensorflow.keras.initializers import RandomNormal,GlorotUniform
from tensorflow.keras.regularizers import l2
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint,EarlyStopping
from dataclasses import dataclass
from typing import Optional
from io import TextIOBase
gpus = tf.config.experimental.list_physical_devices('GPU')
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        logical_gpus = tf.config.experimental.list_logical_devices('GPU')
        print(len(gpus), "Physical GPUs", len(logical_gpus), "Logical GPUs")
    except RuntimeError as e:
        print(e)

np.set_printoptions(threshold=sys.maxsize)
models = sys.argv[1]+"_model"

# create a file folder for saving trained models 
if not os.path.exists(models):
    os.mkdir(models)
    print('{0} create successful!'.format(models))
else:
    print('{0} has been exists.'.format(models))
def comparison(testlabel, resultslabel):
    TP = 0
    FP = 0
    TN = 0
    FN = 0
    for row1 in range(len(resultslabel)):
        if resultslabel[row1] < 0.5:
            resultslabel[row1] = 0
        else:
            resultslabel[row1] = 1
    for row2 in range(len(testlabel)):
        if testlabel[row2] == 1 and testlabel[row2] == resultslabel[row2]:
            TP = TP + 1
        if testlabel[row2] == 0 and testlabel[row2] != resultslabel[row2]:
            FP = FP + 1
        if testlabel[row2] == 0 and testlabel[row2] == resultslabel[row2]:
            TN = TN + 1
        if testlabel[row2] == 1 and testlabel[row2] != resultslabel[row2]:
            FN = FN + 1
    if TP + FN != 0:
        TPR = TP / (TP + FN)
    else:
        TPR = 0
    if TN + FP != 0:
        TNR = TN / (TN + FP)
    else:
        TNR = 0
    if TP + FP != 0:
        PPV = TP / (TP + FP)
    else:
        PPV = 0
    if TN + FN != 0:
        NPV = TN / (TN + FN)
    else:
        NPV = 0
    if FN + TP != 0:
        FNR = FN / (FN + TP)
    else:
        FNR = 0
    if FP + TN != 0:
        FPR = FP / (FP + TN)
    else:
        FPR = 0
    if FP + TP != 0:
        FDR = FP / (FP + TP)
    else:
        FDR = 0
    if FN + TN != 0:
        FOR = FN / (FN + TN)
    else:
        FOR = 0
    if TP + TN + FP + FN != 0:
        ACC = (TP + TN) / (TP + TN + FP + FN)
    else:
        ACC = 0
    if TP + FP + FN != 0:
        F1 = (2 * TP) / (2 * TP + FP + FN)
    else:
        F1 = 0
    if (TP + FP) * (TP + FN) * (TN + FP) * (TN + FN) != 0:
        MCC = (TP * TN + FP * FN) / math.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))
    else:
        MCC = 0
    if TPR != 0 and TNR != 0:
        BM = TPR + TNR - 1
    else:
        BM = 0
    if PPV != 0 and NPV != 0:
        MK = PPV + NPV - 1
    else:
        MK = 0
    return TP, FP, TN, FN, TPR, TNR, PPV, NPV, FNR, FPR, FDR, FOR, ACC, F1, MCC, BM, MK

def Matrix(dirs, label_value, num_need):
	files = open(dirs, 'r')
	sample = []
	label = []
	num = 0
	for line in files:
		if re.match('>', line) is None:
			value = np.zeros((201, 4), dtype='float32')
			if len(line.strip()) <= 201:
				for index, base in enumerate(line.strip()):
					if re.match(base, 'A|a'):
						value[index, 0] = 1
					if re.match(base, 'T|t'):
						value[index, 1] = 1
					if re.match(base, 'C|c'):
						value[index, 2] = 1
					if re.match(base, 'G|g'):
						value[index, 3] = 1
				sample.append(value)
				label.append(label_value)
		else:
			num += 1
			if num <= num_need:
				continue
			else:
				break
	files.close()
	return np.array(sample), np.array(label).reshape([np.array(sample).shape[0], 1])



# create training and testing datasets
def CTTD(pos_sample, pos_label, neg_sample, neg_label):
    X = np.row_stack((pos_sample, neg_sample))
    Y = np.row_stack((pos_label, neg_label))
    input_train, input_test, input_label_train, input_label_test = train_test_split(
        X, Y, train_size=0.8, shuffle=True, random_state=20)
    return input_train, input_test, input_label_train, input_label_test

def dense_layer(x,filters = 12,k = 1,regular_rate = 1e-4,drop_rate = 0.2):
    #x = BatchNormalization(epsilon=1.001e-5)(x)
    x = Conv1D(filters = filters*k,kernel_size = 1,strides = 1,padding = 'same',activation = 'relu',
              kernel_initializer = 'glorot_normal', kernel_regularizer = l2(regular_rate))(x)
    x = Conv1D(filters = filters,kernel_size = 3,strides = 1,padding = 'same',activation = 'relu',
              kernel_initializer = 'glorot_normal', kernel_regularizer = l2(regular_rate))(x)
    x = Dropout(drop_rate)(x)
    return x

def dense_block(x,layers = 4,filters = 12,k =1,regular_rate = 1e-4,drop_rate = 0.2):
    for i in range(layers):
        conv = dense_layer(x,filters = filters,k = k,regular_rate = regular_rate,drop_rate=drop_rate)
        x = concatenate([x, conv], axis = 2)    
    return x

def transition_layer(x,compression_rate = 0.5,regular_rate = 1e-4):
    filters = int(x.shape.as_list()[-1]*compression_rate)
    x = Conv1D(filters = filters,kernel_size = 1,strides = 1,padding = 'same',activation = 'relu',
                kernel_initializer = 'glorot_normal', kernel_regularizer = l2(regular_rate))(x)
    x = AveragePooling1D(pool_size = 2)(x)
    return x
  
def dense_model(input_shape = (201, 4),regular_rate = 1e-4):
    inputs = Input(input_shape)
    x = Conv1D(filters = 64,kernel_size = 3,strides = 1,padding = 'same',activation = 'relu',
                kernel_initializer = 'glorot_normal', kernel_regularizer = l2(regular_rate))(inputs)
    x = Conv1D(filters = 64,kernel_size = 3,strides = 1,padding = 'same',activation = 'relu',
                kernel_initializer = 'glorot_normal', kernel_regularizer = l2(regular_rate))(x)
    x = AveragePooling1D(pool_size = 2)(x)
    x = dense_block(x,layers =6 ,filters=12,k = 2)
    x = transition_layer(x)
    x = dense_block(x,layers = 12,filters=12,k = 4)
    x = transition_layer(x)
    x = dense_block(x,layers = 24,filters=12,k = 4)
    x = transition_layer(x)
    x = dense_block(x,layers = 16,filters=12,k = 4)
    x = Flatten()(x)
    x = Dropout(0.2)(x)
    outputs = Dense(1,activation = 'sigmoid',kernel_initializer = 'glorot_normal',kernel_regularizer = l2(regular_rate))(x)
    model = Model(inputs = inputs, outputs = outputs)
    return model


def train(pos_file,neg_file,num_epoch=40,filter_num=12):
    start = time.time()
    out = open(sys.argv[1]+'_result.txt','w')
    #read files and create positive and negitive datasets
    f = open(pos_file, 'r')
    pos_num = f.read().count('>')
    f.close()
    pos_matrix, pos_label = Matrix(dirs=pos_file,
                                   label_value=1,
                                   num_need=pos_num)
    neg_train, neg_label_train = Matrix(dirs=neg_file,
                                        label_value=0,
                                        num_need=pos_num)
    input_train, input_test, input_label_train, input_label_test = CTTD(
        pos_matrix, pos_label, neg_train, neg_label_train)
    out.write('The number of training samples: %s\n' % len(input_train))
    out.write('The number of testing samples: %s\n' % len(input_test))
    # train and test model
    model = dense_model()
    checkpoint = ModelCheckpoint(filepath= models +'/checkmodel.hdf5', verbose=0, save_best_only=True, monitor='val_loss', mode='min')
    
    model.compile(loss='binary_crossentropy',optimizer=Adam(lr=0.001),metrics=['accuracy'])
    early_stopping =EarlyStopping(monitor='val_loss', patience=5)
    result = model.fit(input_train,
                       input_label_train,
                       batch_size=128,
                       epochs=40,
                       shuffle=True,
                       validation_data=(input_test, input_label_test),
                       callbacks=[checkpoint])
    y_pred = model.predict(input_test, verbose=1)
    fpr, tpr, threshold = roc_curve(input_label_test,y_pred)
    te_roc_auc = auc(fpr,tpr)
    f3 = open(sys.argv[1]+"_performance_metrices.txt",'w')
    f3.writelines("TP"+"\t"+"TN"+"\t"+"FN"+"\t"+"FP"+"\t"+"TPR"+"\t"+"TNR"+"\t"+"ACC"+"\t"+"F1"+"\t"+"MCC"+"\t"+"auc"+"\n")

    TP, FP, TN, FN, TPR, TNR, PPV, NPV, FNR, FPR, FDR, FOR, ACC, F1, MCC, BM, MK = comparison(input_label_test,y_pred)

    f3.writelines(str(TP)+"\t"+str(TN)+"\t"+str(FN)+"\t"+str(FP)+"\t"+str(TPR)+"\t"+str(TNR)+"\t"+str(ACC)+"\t"+str(F1)+"\t"+str(MCC)+"\t"+str(te_roc_auc)+"\n")
    f3.close() 
    
    
    end = time.time()
    training_time = end - start
    val_acc_value = 0
    out.write('epoch\ttrain_loss\ttrain_acc\tval_loss\tval_acc\n')
    for epochs in range(len(result.epoch)):
        if float(result.history['val_accuracy'][epochs]) >= val_acc_value:
            val_acc_value = float(result.history['val_accuracy'][epochs])
            epoch_value = result.epoch[epochs]
            acc_value = result.history['accuracy'][epochs]
    out.write('\nThe optimal condition:\n')
    out.write('\tepoch: %s\n' % epoch_value)
    out.write('\ttrain_acc: %s\n' % acc_value)
    out.write('\tval_acc: %s\n' % val_acc_value)
    out.write('\tusing time: %s\n' % training_time)
    out.close()


def main():
    pos_file = sys.argv[1]+"_pos.fa"
    neg_file = sys.argv[1]+"_neg.fa"
    train(pos_file, neg_file)
if __name__ == "__main__":
	main()
