import pandas as pd
import numpy as np
from translate  import seq_to_shape
import sys

#sample_num = 1816
#sample_num = 598858
#seq_len=101
sam_n=[]
for line in open(sys.argv[1]+"_sequence.table",'r'):
    line_list = line.strip('\n').split(' ')
    sam_n.append(line_list)
seq_len = len(line_list[0])
sample_num=len(sam_n)
output = np.zeros(shape=(sample_num, 197, 14)) # for 200 bp 200-5
#output = np.zeros(shape=(sample_num, 97, 14))

i = 0
for line in open(sys.argv[1]+"_input_seq.table",'r'):
#for line in open('../../03-sequence-dataset/02-seqlen-101/model-input-seq.table','r'):
    #print(i)
    line_list = line.strip('\n').split('\t')
    #print(line_list[1])
    seq_name, seq = line_list[0], line_list[1]
    shape_info = np.array(seq_to_shape(seq, normalize=True).drop([1,2,seq_len-1,seq_len]))
    output[i,:,:] = shape_info
    i+=1

np.save(sys.argv[1]+"_DNA_shape.npy",output)
#np.save("model-input-DNAshape-normalized-101.npy",output)
