import pandas as pd
import h5py
import sys

data = pd.read_csv('test/'+sys.argv[1]+'_model-input-labels.txt', sep='\t')

#df['code'] = df['code'].astype(float)
#df['code'] = df['code'].astype(float)
data[data.iloc[:,3::] >=0.8] = 1
data[data.iloc[:,3::] < 0.8] = 0

data.to_csv('test/'+sys.argv[1]+'_label.txt', index=False, sep='\t')
