import os
from Bio import SeqIO
import re
import sys

with open(sys.argv[1]+'_input_seq.table', 'w') as f:
    for seq_record in SeqIO.parse(sys.argv[1]+"_seq.fa", "fasta"):
        if re.match('^[ACGT]+$', str(seq_record.seq)) and len(str(seq_record.seq)) >=51: # == 51 was given   
            print(seq_record.id, seq_record.seq, sep='\t', file=f)
