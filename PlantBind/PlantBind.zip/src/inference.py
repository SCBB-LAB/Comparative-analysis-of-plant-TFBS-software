import os
import torch
import numpy as np
import pandas as pd

import torch
from torch.utils.data import Dataset, DataLoader

import os
import numpy as np
import pandas as pd
from math import sqrt
from sklearn.metrics import recall_score,precision_score,roc_auc_score,roc_curve, average_precision_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_recall_curve


from model import PlantBind
from utils import data_format

## \u8bfb\u53d6\u6570\u636e
def Onehot(input_data):
    seq = list(input_data.iloc[:,0])
    # seq = seq.cpu().numpy()
    bicoding_dict={'A':[1,0,0,0],'C':[0,1,0,0],'G':[0,0,1,0],'T':[0,0,0,1],'N':[0,0,0,0],
                    'K':[0,0,0,0],'W':[0,0,0,0],'Y':[0,0,0,0],'R':[0,0,0,0],'M':[0,0,0,0],'S':[0,0,0,0]}
    final_bicoding=[]
    for each_seq in seq:
        feat_bicoding=[]
        for each_nt in each_seq:
            feat_bicoding += bicoding_dict[str(each_nt)]
        final_bicoding.append(feat_bicoding)

    return final_bicoding

class PlantBindDataset(Dataset): #\u5206\u522b\u5bfc\u5165\u4e00\u4e2a\u6570\u636e\uff0c\u53ef\u9009\u62e9 train / test / valid
    def __init__(self, data_dir_path):
        self.data_dir = data_dir_path 
        
        # \u8bfb\u53d6\u5e8f\u5217\u4fe1\u606f		
        self.seq = pd.read_table(os.path.join(self.data_dir,"sequence.table"),header=None)
        self.seq_oht = np.array(Onehot(self.seq)) #(seqnum, 404)
        # \u8bfb\u53d6\u5e8f\u5217\u7ed3\u6784\u4fe1\u606f
        self.DNA_shape = np.load(os.path.join(self.data_dir,"DNA_shape.npy")) #(seqnum, 97, 14)

    def __getitem__(self, index):

        x = self.seq_oht[index,...]
        z = self.DNA_shape[index,...]

        x = torch.from_numpy(x)
        z = torch.from_numpy(z)

        x = x.type('torch.cuda.FloatTensor')
        z = z.type('torch.cuda.FloatTensor')

        return (x, z)

    def __len__(self):
        return self.seq_oht.shape[0]


# setting the parameters
length = 101
num_task = 315
data_path = '/DATA1/PlantBind/data_folder'
model_weights = '/DATA1/PlantBind/data/model/trained_model_101_seqs.pkl'
#model_weights = '/home/wkyan/ywk_lab/03_PlantBind/04-training/02-seq-101/01-bs-1024-lr-0.01/output/trained_model_101_seqs.pkl'
data_type = 'test'
TF_index = 203-1

torch.cuda.empty_cache()

print('Message: Loading testing data!') #\u6d4b\u8bd5\u6570\u636e
test_data = PlantBindDataset(data_path)

# ##\u5f00\u59cb\u7a0b\u5e8f##
model = PlantBind(seq_len=length, num_task=num_task)
model.cuda()

print('Message: Loading saved model!') #\u52a0\u8f7d\u6a21\u578b
model.load_state_dict(torch.load(model_weights)) #\u8bfb\u53d6\u6700\u597d\u7684\u6a21\u578b
#model.eval()

x, z = test_data[:]
X, z = data_format(DNA_Seq=x, DNA_Shape=z)
print(X.size(), z.size())

#pos_num = X.size(0)//2
#neg_num = X.size(0) - pos_num
#y = np.concatenate((np.ones(pos_num),np.zeros(neg_num)))

pos_num = X.size(0)
y = np.ones(pos_num)
#print(y.shape)
#print(y)
#y = pd.read_table(data_path+"/label.txt", header=0)
#y = y.to_numpy()[:,0]  #(seqnum, 315)


try:
    y_pred, attention = model(X.cuda(), z.cuda())
    y_true = y
except RuntimeError: #\u5982\u679c\u4e0a\u4e00\u884c\u6709\u62a5\u9519\u5373\u6267\u884c\u8fd9\u4e00\u884c
    print('Catch RuntimeError, parepare to batch the test set')
    batch_size = 128
    num_iter = X.shape[0] // batch_size
    y_true = y[0:num_iter*batch_size,...]
    
    x_test_tem = X[0:1*batch_size,...]
    z_test_tem = z[0:1*batch_size,...]
    y_pred, attention = model(x_test_tem.cuda(), z_test_tem.cuda())
    for i in range(1, num_iter): # \u4ece1\u5f00\u59cb
        x_test_tem = X[i*batch_size:(i+1)*batch_size,...]
        z_test_tem = z[i*batch_size:(i+1)*batch_size,...]
        y_pred_tem, attn_tem = model(x_test_tem.cuda(), z_test_tem.cuda())
        attention = torch.cat((attention.cpu().detach(), attn_tem.cpu().detach()),dim=0)
        for j in range(num_task):#0\uff0c1\uff0c2\uff0c3....11
            y_pred[j] = torch.cat((y_pred[j].cpu().detach(),y_pred_tem[j].cpu().detach()),dim=0)

print(attention.size())
# ###
y_pred_ = [] #\u4fdd\u5b58\u6240\u6709\u7684y_pred [315, sample_num]
for i in range(len(y_pred)):
    y_pred_.append(list(y_pred[i].cpu().detach().numpy()))
y_pred_T= np.array(y_pred_).T #[sample_num, 315] # \u8f6c\u6362\u4e4b\u540e\u7684\u9884\u6d4b\u7ed3\u679c

print(y_pred_T.shape)

# ###
print('Message: Loading thresholds!')
thresholds = np.loadtxt('/DATA1/PlantBind/output1/Gmean_threshold_b.txt').tolist()
#thresholds = np.loadtxt('/home/wkyan/ywk_lab/03_PlantBind/04-training/02-seq-101/01-bs-1024-lr-0.01/output/Gmean_threshold_m.txt').tolist()
#f = open('output-38.txt','w')
best = 0
for TF_index in range(314):
    best_threshold = thresholds[TF_index]
    #print("best_threshold:",best_threshold)
    y_pred_new = [0 if instance < best_threshold else 1 for instance in list(y_pred_T[:,TF_index])]
    pred = np.sum(y_pred_new)
    #print(TF_index+1,pred,sep='\t',file=f)
    print(TF_index+1,pred)
    if pred > best:
       print("best:",TF_index+1,pred)
       best = pred
    #print(y_pred_T[:,TF_index][0:100])

#for TF_index in range(315):
#    auc_b = roc_auc_score(y_true, y_pred_T[:,TF_index]) 
#    ap_b = average_precision_score(y_true, y_pred_T[:,TF_index])
#    print('auc_b', auc_b)
#    print('ap_b', ap_b)
