import json
import numpy as np
import torch

from utils import cal_metrics, data_format

def test(model, test_data, args):

    DNA_seq_test, DNA_label_test, DNA_shape_test = test_data[:]
    DNA_seq_test, DNA_shape_test = data_format(DNA_Seq=DNA_seq_test, DNA_Shape=DNA_shape_test)
    x, y_true, z = DNA_seq_test, DNA_label_test, DNA_shape_test

    model.eval()
    try:
        y_pred, attention = model(x.cuda(), z.cuda())
    except RuntimeError: #\u5982\u679c\u4e0a\u4e00\u884c\u6709\u62a5\u9519\u5373\u6267\u884c\u8fd9\u4e00\u884c
        print('Catch RuntimeError, parepare to batch the test set'+ '-'* 50)
        batch_size = 128
        num_iter = x.shape[0] // batch_size
        y_true = y_true[0:num_iter*batch_size,...]
        x_test_tem = x[0:1*batch_size,...]
        z_test_tem = z[0:1*batch_size,...]
        y_pred, attention = model(x_test_tem.cuda(), z_test_tem.cuda())
        for i in range(1, num_iter): # \u4ece1\u5f00\u59cb
            x_test_tem = x[i*batch_size:(i+1)*batch_size,...]
            z_test_tem = z[i*batch_size:(i+1)*batch_size,...]
            y_pred_tem, attn_tem = model(x_test_tem.cuda(), z_test_tem.cuda())
            for j in range(args.num_task):#0\uff0c1\uff0c2\uff0c3....11
                y_pred[j] = torch.cat((y_pred[j].cpu().detach(),y_pred_tem[j].cpu().detach()),dim=0)

    class_names = test_data.class_name

    #\u4fdd\u5b58\u6240\u6709\u9884\u6d4b\u7ed3\u679c/\u5c0f\u6570\u70b9 ,\u5e76\u6539\u53d8\u4e3alabel\u7684\u5f62\u72b6
    y_pred_ = [] #\u4fdd\u5b58\u6240\u6709\u7684y_pred [315, sample_num]
    for i in range(len(y_pred)):
        y_pred_.append(list(y_pred[i].cpu().detach().numpy()))
    y_pred_T= np.array(y_pred_).T #[sample_num, 315] # \u8f6c\u6362\u4e4b\u540e\u7684\u9884\u6d4b\u7ed3\u679c
    np.savetxt(args.save_dir+'/DNA_lable_True.txt', y_true.cpu().detach().numpy(),fmt='%d') #\u6574\u6570
    np.savetxt(args.save_dir+'/DNA_lable_Pred.txt', y_pred_T,fmt='%f')
    # evaluate the model
    metrics_b, metrics_m = cal_metrics(model_out=y_pred_T, label=y_true, plot=True, args=args)

    print('-'*35+"End Testing"+"-"*35)
    print()
    print('-'*35+"Save Result"+"-"*35)

    #! \u4fdd\u5b58metries-> pf.json

    metrics_b_save_path = "%s/metrics_b.json" %(args.save_dir)
    metrics_m_save_path = "%s/metrics_m.json" %(args.save_dir)


    with open(metrics_b_save_path,'w') as fp:
        json.dump(metrics_b, fp)
    with open(metrics_m_save_path,'w') as fp:
        json.dump(metrics_m, fp)
    
    print("Storing performance results to %s" %(args.save_dir))
