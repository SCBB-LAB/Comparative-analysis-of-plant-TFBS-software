import pandas as pd
import sys

from sklearn.model_selection import train_test_split

infile_pos=[x.strip() for x in open(sys.argv[1]).readlines()]
infile_neg=[x.strip() for x in open(sys.argv[2]).readlines()]


# train is now 75% of the entire data set
# the _junk suffix means that we drop that variable completely
p_train, p_test, n_train, n_test = train_test_split(infile_pos, infile_neg, test_size=0.30)

# test is now 10% of the initial data set
# validation is now 15% of the initial data set
p_train, p_val, n_train, n_val = train_test_split(p_train, n_train, test_size=0.10) 

f1= open(sys.argv[3],"w+")
for i in p_train:
	f1.write(i+'\n')
f1.close()

f1= open(sys.argv[3],"a")
for i in n_train:
	f1.write(i+'\n')
f1.close()

f1= open(sys.argv[4],"w+")
for i in p_test:
	f1.write(i+'\n')
f1.close()

f1= open(sys.argv[4],"a")
for i in n_test:
	f1.write(i+'\n')
f1.close()

f1= open(sys.argv[5],"w+")
for i in p_val:
	i = i.replace('\t',' ')
	f1.write(i+'\n')
f1.close()

f1= open(sys.argv[5],"a")
for i in n_val:
	f1.write(i+'\n')
f1.close()
