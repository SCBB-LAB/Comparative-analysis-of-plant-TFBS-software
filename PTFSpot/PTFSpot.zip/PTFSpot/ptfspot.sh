#!/bin/sh
mkdir result plot
python3 1.py $1 $2
python3 ptfspot.py $3 $1 $2 >$2/tmp
sed 's+_+\t+' $2/tmp >$2/tmp2
awk '{if($2>=0.6) print $1"\t"$2}' $2/tmp |sed 's+_+\t+'|sed 's+>++'|awk '{print $1"\t"$2"\t"$2+160"\t"$3}'|sortBed -i - |mergeBed -i -|awk 'BEGIN{print "ID\tStart\tEnd"}{print $1"\t"$2"\t"$3}' >result/$3\_$1.txt
