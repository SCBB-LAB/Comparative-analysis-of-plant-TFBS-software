import plotly.graph_objects as go
import plotly.express as px
import os, sys
import pandas as pd
import numpy as np
import plotly.graph_objects as go
filename=str(sys.argv[1])
df = pd.read_csv("plot/"+filename,sep="\t")
l1=list(df["Coordinate"])
l2=list(df["Line"])
l4=[]
for i, j in enumerate(l1):
	l4.append("<b>"+str(j)+"</b>")


fig = px.line(df, x="Coordinate", y="Line")
fig.update_layout(
    xaxis = dict(
        tickvals = l1,
        ticktext = l4
    )
)
fig.update_yaxes(
        title_text = "T-Score",
        title_font = {"size": 20},
        title_standoff = 25)

fig.update_xaxes(
        title_text = "Position",
        title_font = {"size": 20},
        title_standoff = 25)

fig.update_traces(line=dict(color="orange", width=4))

fig.show()

