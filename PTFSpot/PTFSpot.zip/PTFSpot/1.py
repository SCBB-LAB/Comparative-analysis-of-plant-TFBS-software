import sys, os

infile=[x.strip() for x in open(sys.argv[2]+"/"+sys.argv[1]).readlines()]
fastadict={}
for line in infile:
    if not line:
        continue
    if line.startswith('>'):
        sname = line
        if line not in fastadict:
            fastadict[line] = ''
        continue
    fastadict[sname] += line

ids=list(fastadict.keys())
seq = list(fastadict.values())

f3=open("result/"+sys.argv[1],'w')
for k,j in enumerate(seq):
	j=j.upper()
	j=j.replace('U', 'T')
	j=j.replace('N', 'A')
	if len(j) >=161:
		kmer=[j[i:i+160] for i in range(0,len(j)-159)]
		for n, m in enumerate(kmer):
			f3.writelines(str(ids[k])+"_"+str(n)+"\t"+str(m)+"\n")
	else:	
		f3.writelines(str(ids[k])+"_0\t"+str(j)+"\n")


f3.close()

