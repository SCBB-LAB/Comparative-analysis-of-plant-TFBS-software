import os
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
from keras.regularizers import l2, l1
import sys, numpy as np, tensorflow as tf, tensorflow, keras, numpy, pandas as pd, warnings, re, math, numpy, pickle, time, sklearn
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from tensorflow.keras.optimizers import Adam, SGD, RMSprop, Adadelta, Adagrad, Adamax, Nadam, Ftrl
from keras.callbacks import EarlyStopping, ModelCheckpoint
from math import floor
from keras.models import Sequential, load_model, Model
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from keras import regularizers, layers
from keras.preprocessing import sequence
from pickle import load
from numpy import array, argmax
from keras.preprocessing.text import Tokenizer
from tensorflow.keras.utils import pad_sequences
from tensorflow.keras.layers import Input, Dense, Flatten, Dropout, Embedding, BatchNormalization, concatenate, LSTM, LeakyReLU
from multiprocessing import Pool
from sklearn.metrics import accuracy_score, recall_score, precision_score, confusion_matrix, classification_report, roc_auc_score, cohen_kappa_score, f1_score, make_scorer
from sklearn import metrics



class TransformerBlock(layers.Layer):
    def __init__(self, embed_dim, num_heads, ff_dim, rate=0.1):
        super(TransformerBlock, self).__init__()
        self.att = layers.MultiHeadAttention(num_heads=num_heads, key_dim=embed_dim, value_dim=embed_dim)
        self.ffn = keras.Sequential(
            [layers.Dense(ff_dim, activation="relu"), layers.Dense(embed_dim),]
        )
        self.layernorm1 = layers.LayerNormalization(epsilon=1e-6)
        self.layernorm2 = layers.LayerNormalization(epsilon=1e-6)
        self.dropout1 = layers.Dropout(rate)
        self.dropout2 = layers.Dropout(rate)
    def call(self, inputs, training):
        attn_output = self.att(inputs, inputs)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(inputs + attn_output)
        ffn_output = self.ffn(out1)
        ffn_output = self.dropout2(ffn_output, training=training)
        return self.layernorm2(out1 + ffn_output)


class TokenAndPositionEmbedding(layers.Layer):
    def __init__(self, maxlen, vocab_size, embed_dim):
        super(TokenAndPositionEmbedding, self).__init__()
        self.token_emb = layers.Embedding(input_dim=vocab_size, output_dim=embed_dim)
        self.pos_emb = layers.Embedding(input_dim=maxlen, output_dim=embed_dim)
    def call(self, x):
        maxlen = tf.shape(x)[-1]
        positions = tf.range(start=0, limit=maxlen, delta=1)
        positions = self.pos_emb(positions)
        x = self.token_emb(x)
        return x + positions

def comparison(testlabel, resultslabel):
    TP = 0
    FP = 0
    TN = 0
    FN = 0
    for row1 in range(len(resultslabel)):
        if resultslabel[row1] < 0.5:
            resultslabel[row1] = 0
        else:
            resultslabel[row1] = 1
    for row2 in range(len(testlabel)):
        if testlabel[row2] == 1 and testlabel[row2] == resultslabel[row2]:
            TP = TP + 1
        if testlabel[row2] == 0 and testlabel[row2] != resultslabel[row2]:
            FP = FP + 1
        if testlabel[row2] == 0 and testlabel[row2] == resultslabel[row2]:
            TN = TN + 1
        if testlabel[row2] == 1 and testlabel[row2] != resultslabel[row2]:
            FN = FN + 1
    if TP + FN != 0:
        TPR = TP / (TP + FN)
    else:
        TPR = 99999
    if TN + FP != 0:
        TNR = TN / (TN + FP)
    else:
        TNR = 999999
    if TP + FP != 0:
        PPV = TP / (TP + FP)
    else:
        PPV = 999999
    if TN + FN != 0:
        NPV = TN / (TN + FN)
    else:
        NPV = 999999
    if FN + TP != 0:
        FNR = FN / (FN + TP)
    else:
        FNR = 999999
    if FP + TN != 0:
        FPR = FP / (FP + TN)
    else:
        FPR = 999999
    if FP + TP != 0:
        FDR = FP / (FP + TP)
    else:
        FDR = 999999
    if FN + TN != 0:
        FOR = FN / (FN + TN)
    else:
        FOR = 999999
    if TP + TN + FP + FN != 0:
        ACC = (TP + TN) / (TP + TN + FP + FN)
    else:
        ACC = 999999
    if TP + FP + FN != 0:
        F1 = (2 * TP) / (2 * TP + FP + FN)
    else:
        F1 = 999999
    if (TP + FP) * (TP + FN) * (TN + FP) * (TN + FN) != 0:
        MCC = (TP * TN + FP * FN) / math.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))
    else:
        MCC = 999999
    if TPR != 999999 and TNR != 999999:
        BM = TPR + TNR - 1
    else:
        BM = 999999
    if PPV != 999999 and NPV != 999999:
        MK = PPV + NPV - 1
    else:
        MK = 999999
    return TP, FP, TN, FN, TPR, TNR, PPV, NPV, FNR, FPR, FDR, FOR, ACC, F1, MCC, BM, MK


length=310+160
def create_tokenizer(lines):
	tokenizer = Tokenizer()
	tokenizer.fit_on_texts(lines)
	return tokenizer



def max_length(lines):
	return max([len(s.split()) for s in lines])

def encode_text(tokenizer, lines, length):
	encoded = tokenizer.texts_to_sequences(lines)
	padded = pad_sequences(encoded, maxlen=length, padding='post')
	return padded

import itertools
bases=['A','T','G','C']
m=[]
for p,j in itertools.product(bases, repeat=2):
	m.append(p+j)

o=' '.join(m)
m=[]
for p,j,a,b,c in itertools.product(bases, repeat=5):
	m.append(p+j+a+b+c)

m=' '.join(m)
n=[]
for p,j,a,b,c,d,e in itertools.product(bases, repeat=7):
	n.append(p+j+a+b+c+d+e)

n=' '.join(n)
a=[str(o)+' '+str(m)+' '+str(n)]
tokenizer=create_tokenizer(a)
vocab_size = len(tokenizer.word_index) + 1

embed_dim = 28
num_heads = 14
ff_dim = 14

def max_length(lines):
	return max([len(s.split()) for s in lines])

def encode_text(tokenizer, lines, length):
	encoded = tokenizer.texts_to_sequences(lines)
	padded = pad_sequences(encoded, maxlen=length, padding='post')
	return padded



import numpy as np, os, sys, pdbset
from timeit import default_timer as timer

def s1(k):
	a=[]
	text5=[train_img[k][i:i+5] for i in range(len(train_img[k])-(4))]
	text7=[train_img[k][i:i+7] for i in range(len(train_img[k])-6)]
	text2=[train_img[k][i:i+2] for i in range(len(train_img[k])-1)]
	texts62=' '.join(text7)
	texts72=' '.join(text5) 
	texts22=' '.join(text2) 
	a.append(str(texts22)+" "+str(texts62)+" "+str(texts72))
	f2 = encode_text(tokenizer, a, length)
	return f2

def s2(k):
	a=[]
	text5=[test_img[k][i:i+5] for i in range(len(test_img[k])-(4))]
	text7=[test_img[k][i:i+7] for i in range(len(test_img[k])-6)]
	text2=[test_img[k][i:i+2] for i in range(len(test_img[k])-1)]
	texts62=' '.join(text7)
	texts72=' '.join(text5) 
	texts22=' '.join(text2) 
	a.append(str(texts22)+" "+str(texts62)+" "+str(texts72))
	f2 = encode_text(tokenizer, a, length)
	return f2


from keras.layers import Input, Dense, Flatten, Dropout, Embedding, BatchNormalization, concatenate, LSTM, LeakyReLU
from keras.layers import Conv2D, MaxPooling2D
import keras
from keras.models import Model
from keras.layers import Conv2D, MaxPooling2D, Dense, Input, Activation, Dropout, GlobalAveragePooling2D,BatchNormalization, concatenate, AveragePooling2D
from keras.optimizers import Adam


def conv_layer(conv_x, filters):
    conv_x = BatchNormalization()(conv_x)
    conv_x = Activation('relu')(conv_x)
    conv_x = Conv2D(filters, (3, 3), kernel_initializer='he_uniform', padding='same', use_bias=False)(conv_x)
    conv_x = Dropout(0.2)(conv_x)
    return conv_x

def dense_block(block_x, filters, growth_rate, layers_in_block):
    for i in range(layers_in_block):
        each_layer = conv_layer(block_x, growth_rate)
        block_x = concatenate([block_x, each_layer], axis=-1)
        filters += growth_rate
    return block_x, filters



dense_block_size = 10
layers_in_block = 4
growth_rate = 16
classes = 1


embed_dim = 28
num_heads = 14
ff_dim = 14

inputs = layers.Input(shape=(length,))
embedding_layer = TokenAndPositionEmbedding(length, vocab_size, embed_dim)
x = embedding_layer(inputs)
transformer_block = TransformerBlock(embed_dim, num_heads,ff_dim)
x = transformer_block(x)
x = layers.GlobalAveragePooling1D()(x)
x = layers.Dropout(0.25)(x)
x = layers.Dense(24, activation="relu")(x)

inputShape1 = (300, 24, 3)
inputs1 = Input(shape=inputShape1)
conv1 = Conv2D(32, (3, 3), padding='same', activation="elu")(inputs1)
batch1 = BatchNormalization()(conv1)
dense_x = MaxPooling2D(pool_size=(2, 2))(batch1)

for block in range(dense_block_size - 1):
        dense_x, filters = dense_block(dense_x, growth_rate * 2, growth_rate, 4)
        trans_x = BatchNormalization()(dense_x)
        trans_x = Activation('relu')(trans_x)
        trans_x = Conv2D(filters, (3, 3), kernel_initializer='he_uniform', padding='same', use_bias=False)(trans_x)
        batch1 = BatchNormalization()(trans_x)
        trans_x = MaxPooling2D((1, 1), strides=(2, 2))(batch1)
        dense_x, filters=trans_x, filters
        each_layer = conv_layer(dense_x, growth_rate)
        block_x = concatenate([dense_x, each_layer], axis=-1)
        filters += growth_rate
        dense_x, filters1= block_x, filters


dense_x = Flatten()(dense_x)
mode = concatenate([x, dense_x])
batch_model = BatchNormalization(name="my_dense")(mode)
drop = Dropout(0.15)(batch_model)
drop = Dense(20, activation="selu")(drop)
drop = Dropout(0.15)(drop)
outputs = Dense(1, activation="sigmoid")(drop)
nn = Model(inputs=[inputs,inputs1], outputs=outputs)
nn.compile(loss='binary_crossentropy', optimizer="adam", metrics=['accuracy'])
nn.load_weights('utils/bimodal.h5')


jj=str(sys.argv[1])

what = str(sys.argv[2])

pdb_res = pdbset.result(jj, "pdb/")

import os, sys
train_img=[]
train_label=[]
train_pdb=[]
test_img=[]
test_label=[]
test_pdb=[]



f1=open("result/"+what,'r')
for i in f1:
	z=i.split()
	train_label.append(str(z[0]))
	j=z[1]
	train_img.append(j.upper())
	train_pdb.append(pdb_res)
f1.close()
name4 = Pool().map(s1, [sent for sent in range(len(train_img))])
name4 = np.array(name4)
name4 = name4.reshape(name4.shape[0], name4.shape[2])
train_pdb = np.array(train_pdb)
y_pred = nn.predict([name4, train_pdb], verbose = 0)
for i, j in enumerate(y_pred):
	print(str(train_label[i])+"\t"+str(j[0]))
	

