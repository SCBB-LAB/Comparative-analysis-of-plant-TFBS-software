./peakranger ranger -d treated_file_name.bam -c control_file_name.bam -o treated_file_name_out.txt --format bam
