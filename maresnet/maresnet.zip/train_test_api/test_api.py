"""
test_api
author Long-Chen Shen
"""
import time
import numpy as np
import pandas as pd
import torch
import math
import os
from sklearn.metrics import confusion_matrix
from conf import settings
from sklearn.metrics import roc_curve, auc, roc_auc_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import matthews_corrcoef
@torch.no_grad()
def comparison(testlabel, resultslabel):
    TP = 0
    FP = 0
    TN = 0
    FN = 0
    for row1 in range(len(resultslabel)):
        if resultslabel[row1] < 0.5:
            resultslabel[row1] = 0
        else:
            resultslabel[row1] = 1
    for row2 in range(len(testlabel)):
        if testlabel[row2] == 1 and testlabel[row2] == resultslabel[row2]:
            TP = TP + 1
        if testlabel[row2] == 0 and testlabel[row2] != resultslabel[row2]:
            FP = FP + 1
        if testlabel[row2] == 0 and testlabel[row2] == resultslabel[row2]:
            TN = TN + 1
        if testlabel[row2] == 1 and testlabel[row2] != resultslabel[row2]:
            FN = FN + 1
    if TP + FN != 0:
        TPR = TP / (TP + FN)
    else:
        TPR = 0
    if TN + FP != 0:
        TNR = TN / (TN + FP)
    else:
        TNR = 0
    if TP + FP != 0:
        PPV = TP / (TP + FP)
    else:
        PPV = 0
    if TN + FN != 0:
        NPV = TN / (TN + FN)
    else:
        NPV = 0
    if FN + TP != 0:
        FNR = FN / (FN + TP)
    else:
        FNR = 0
    if FP + TN != 0:
        FPR = FP / (FP + TN)
    else:
        FPR = 0
    if FP + TP != 0:
        FDR = FP / (FP + TP)
    else:
        FDR = 0
    if FN + TN != 0:
        FOR = FN / (FN + TN)
    else:
        FOR = 0
    if TP + TN + FP + FN != 0:
        ACC = (TP + TN) / (TP + TN + FP + FN)
    else:
        ACC = 0
    if TP + FP + FN != 0:
        F1 = (2 * TP) / (2 * TP + FP + FN)
    else:
        F1 = 0
    if (TP + FP) * (TP + FN) * (TN + FP) * (TN + FN) != 0:
        MCC = (TP * TN + FP * FN) / math.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))
    else:
        MCC = 0
    if TPR != 0 and TNR != 0:
        BM = TPR + TNR - 1
    else:
        BM = 0
    if PPV != 0 and NPV != 0:
        MK = PPV + NPV - 1
    else:
        MK = 0
    return TP, FP, TN, FN, TPR, TNR, PPV, NPV, FNR, FPR, FDR, FOR, ACC, F1, MCC, BM, MK

def eval_training(net, dna_valid_loader, dna_test_loader, loss_function, softmax_output,
                  args, epoch=0, df_file=None, log_dic=None, train_after=False):
    print()
    print('============== Evaluating Network Start ==============')
    start = time.time()
    net.eval()
    # valid evaluating
    loss_valid, acc_valid, auc_valid, pred_result_valid = eval_model(net=net, dataloader=dna_valid_loader,
                                                                     loss_function=loss_function,
                                                                     softmax_output=softmax_output,
                                                                     args=args)

    finish = time.time()
    print(' Valid set: Epoch: {}, Average loss: {:.4f}, Accuracy: {:.4f}, AUC: {:.4f}, Time consumed:{:.2f}s'.format(
        epoch,
        loss_valid,
        acc_valid,
        auc_valid,
        finish - start
    ))

    # test evaluating
    start = time.time()
    loss_test, acc_test, auc_test, pred_result_test = eval_model(net=net, dataloader=dna_test_loader,
                                                                 loss_function=loss_function,
                                                                 softmax_output=softmax_output,
                                                                 args=args)

    finish = time.time()
    cur_result = ' Test set:  Epoch: {}, Average loss: {:.4f}, Accuracy: {:.4f}, AUC: {:.4f}, Time consumed:{:.2f}s' \
        .format(epoch, loss_test, acc_test, auc_test, finish - start)
    print(' Test set:  Epoch: {}, Average loss: {:.4f}, Accuracy: {:.4f}, AUC: {:.4f}, Time consumed:{:.2f}s'.format(
        epoch,
        loss_test,
        acc_test,
        auc_test,
        finish - start
    ))
    print('=============== Evaluating Network End ===============')
    print()
    if log_dic is not None and train_after:
        log_dic['valid_loss'] = loss_valid
        log_dic['valid_acc'] = acc_valid
        log_dic['valid_auc'] = auc_valid

        log_dic['test_loss'] = loss_test
        log_dic['test_acc'] = acc_test
        log_dic['test_auc'] = auc_test
        df = pd.read_csv(df_file, sep='\t')
        
        #df = pd.read_pickle(df_file)
        df = df.append([log_dic])
        df.reset_index(inplace=True, drop=True)
        #df.to_pickle(df_file)
        df.to_csv(df_file, sep='\t')

    return auc_valid, cur_result, pred_result_test


def auc_computing(real, pred_numerics):
    for i in range(len(pred_numerics)):
        if np.isnan(pred_numerics[i]):
            pred_numerics[i] = 0.5
    fpr, tpr, thresholds = roc_curve(real, pred_numerics)
    roc_auc = auc(fpr, tpr)
    
    return roc_auc

dataset_path = os.path.join( "example/") # all TFs data for train, test and valid should be in user defined directory
dataset_list = sorted(os.listdir(dataset_path))

def eval_model(net, dataloader, loss_function, softmax_output, args):
    loss_all = 0.0
    correct = 0.0
    prob_all = []
    label_all = []
    y_true = []
    y_pred = []
    
    for item in dataloader:
        
        #CM=0
        
        dna_seqs = item['seq'].to(args.device).float()
        labels = item['label'].to(args.device)
        #print(labels)
        y_true.extend(labels.cpu().data.numpy())
        
        
        outputs = net(dna_seqs)
        
        _, predicted = torch.max(outputs, 1)
        
        y_pred.extend(predicted.cpu().data.numpy())
        
        
        loss = loss_function(outputs, labels)
        prob = softmax_output(outputs)
        loss_all += loss.item() * dna_seqs.size(0)
        
        
        _, pred = outputs.max(1)
        prob_all.extend(prob[:, 1].cpu().data.numpy())
        label_all.extend(labels.cpu().data.numpy())

   
        correct += pred.eq(labels).sum().item()
    
    CM = confusion_matrix(y_true, y_pred)
    #print(CM)
    tn=CM[0][0]
    tp=CM[1][1]
    fp=CM[0][1]
    fn=CM[1][0]

    acc=np.sum(np.diag(CM)/np.sum(CM))
    sensitivity=tp/(tp+fn)
    precision=tp/(tp+fp)

    
   # print('\nTestset Accuracy(mean): %f %%' % (100 * acc))
    print()
    #print('Confusion Matirx : ')
    #print(CM)
    sensitivity=((tp/(tp+fn))*100)
    specificity = ((tn/(tn+fp))*100)
    Precision= ((tp/(tp+fp))*100)
    NPV= ((tn/(tn+fn))*100)
    F1=(((2*sensitivity*precision)/(sensitivity+precision))*100)
    MCC=(matthews_corrcoef(y_true, y_pred)*100)
    print()
    TP, FP, TN, FN, TPR, TNR, PPV, NPV, FNR, FPR, FDR, FOR, ACC, F1, MCC, BM, MK = comparison(y_true,y_pred)

    f3 = open("output/checkpoint/"+dataset_list[0]+'/epoch_wise_result.txt','a+')
    
    eval_auc = auc_computing(label_all, prob_all)
    f3.writelines(str(tp)+"\t"+str(tn)+"\t"+str(fn)+"\t"+str(fp)+"\t"+str(sensitivity)+"\t"+str(precision)+"\t"+str(acc)+"\t"+str(F1)+"\t"+str(MCC)+"\t"+str(eval_auc)+"\n")
    #f3 = open(df_path+'/df_log2.csv','a+')
    f3.close()
    
    avg_loss = loss_all / len(dataloader.dataset)
    eval_acc = correct / len(dataloader.dataset)
    eval_auc = auc_computing(label_all, prob_all)
    
    
    return avg_loss, eval_acc, eval_auc, prob_all

