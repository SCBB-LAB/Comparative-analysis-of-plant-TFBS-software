#import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import time
import os 
import sys

np.random.seed(12580)

in_file = sys.argv[1]
name = in_file.split('_')[0]
def comparison(testlabel, resultslabel):
    TP = 0
    FP = 0
    TN = 0
    FN = 0
    for row1 in range(len(resultslabel)):
        if resultslabel[row1] < 0.5:
            resultslabel[row1] = 0
        else:
            resultslabel[row1] = 1
    for row2 in range(len(testlabel)):
        if testlabel[row2] == 1 and testlabel[row2] == resultslabel[row2]:
            TP = TP + 1
        if testlabel[row2] == 0 and testlabel[row2] != resultslabel[row2]:
            FP = FP + 1
        if testlabel[row2] == 0 and testlabel[row2] == resultslabel[row2]:
            TN = TN + 1
        if testlabel[row2] == 1 and testlabel[row2] != resultslabel[row2]:
            FN = FN + 1
    if TP + FN != 0:
        TPR = TP / (TP + FN)
    else:
        TPR = 0
    if TN + FP != 0:
        TNR = TN / (TN + FP)
    else:
        TNR = 0
    if TP + FP != 0:
        PPV = TP / (TP + FP)
    else:
        PPV = 0
    if TN + FN != 0:
        NPV = TN / (TN + FN)
    else:
        NPV = 0
    if FN + TP != 0:
        FNR = FN / (FN + TP)
    else:
        FNR = 0
    if FP + TN != 0:
        FPR = FP / (FP + TN)
    else:
        FPR = 0
    if FP + TP != 0:
        FDR = FP / (FP + TP)
    else:
        FDR = 0
    if FN + TN != 0:
        FOR = FN / (FN + TN)
    else:
        FOR = 0
    if TP + TN + FP + FN != 0:
        ACC = (TP + TN) / (TP + TN + FP + FN)
    else:
        ACC = 0
    if TP + FP + FN != 0:
        F1 = (2 * TP) / (2 * TP + FP + FN)
    else:
        F1 = 0
    if (TP + FP) * (TP + FN) * (TN + FP) * (TN + FN) != 0:
        MCC = (TP * TN + FP * FN) / math.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))
    else:
        MCC = 0
    if TPR != 0 and TNR != 0:
        BM = TPR + TNR - 1
    else:
        BM = 0
    if PPV != 0 and NPV != 0:
        MK = PPV + NPV - 1
    else:
        MK = 0
    return TP, FP, TN, FN, TPR, TNR, PPV, NPV, FNR, FPR, FDR, FOR, ACC, F1, MCC, BM, MK



def Seq2mat(seq):
	mat1 = np.zeros([4,len(seq)])
	mat2 = np.zeros([4,len(seq)])
	for letter,index in zip(seq,range(len(seq))):
		if letter == 'A' or letter == 'a':
			mat1[0,index] = 1
			mat2[3,len(seq)-index-1]=1
		if letter == 'C' or letter == 'c':
			mat1[1,index] = 1
			mat2[2,len(seq)-index-1]=1
		if letter == 'G' or letter == 'g':
			mat1[2,index] = 1
			mat2[1,len(seq)-index-1]=1
		if letter == 'T' or letter == 't':
			mat1[3,index] = 1
			mat2[0,len(seq)-index-1]=1
		if letter == 'N':
			pass
	return mat1,mat2

def mat2Mat(filename):
	Mat = []
	Tag = []
	with open(filename) as f:
		for line in f.readlines():
			tag = line.split()[0]
			seq = line.split()[1]
			mat1,mat2 = Seq2mat(seq)
			Mat.append([mat1,mat2])
			Tag=np.append(Tag,float(tag))
	return np.array(Mat),Tag
Mat,Tag = mat2Mat('example/'+in_file+"_train.txt")

from keras.utils import np_utils
from collections import Counter
from tensorflow.keras.utils import pad_sequences
from sklearn.metrics import roc_curve, auc, average_precision_score

x_train,x_test,y_train,y_test=train_test_split(Mat,Tag,test_size=0.1,random_state=12580)

x_train_1 = x_train[:,0,:,:]
x_train_1 = x_train_1.reshape(x_train_1.shape[0],x_train_1.shape[2],4)
x_train_1 = pad_sequences(x_train_1, maxlen=201, padding='post')
x_train_1 = x_train_1.reshape(x_train_1.shape[0],4,201,1)

x_train_2 = x_train[:,1,:,:]
x_train_2 = x_train_2.reshape(x_train_2.shape[0],x_train_2.shape[2],4)
x_train_2 = pad_sequences(x_train_2, maxlen=201, padding='post')
x_train_2 = x_train_2.reshape(x_train_2.shape[0],4,201,1)

x_test_1 = x_test[:,0,:,:]
x_test_1 = x_test_1.reshape(x_test_1.shape[0],x_test_1.shape[2],4)
x_test_1 = pad_sequences(x_test_1, maxlen=201, padding='post')
x_test_1 = x_test_1.reshape(x_test_1.shape[0],4,201,1)

x_test_2 = x_test[:,1,:,:]
x_test_2 = x_test_2.reshape(x_test_2.shape[0],x_test_2.shape[2],4)
x_test_2 = pad_sequences(x_test_2, maxlen=201, padding='post')
x_test_2 = x_test_2.reshape(x_test_2.shape[0],4,201,1)


from keras.models import Model
from keras.layers import Input,Dense,Dropout,Flatten
from keras.layers import Convolution2D,MaxPooling2D,AveragePooling2D,ReLU
from tensorflow.keras.layers import BatchNormalization
from keras.layers import ELU, PReLU, LeakyReLU
from keras.utils import plot_model
from keras.callbacks import EarlyStopping
from keras.layers import concatenate
from keras.initializers import random_normal
from keras import regularizers

mat_1 = Input(shape=(4,201,1))
mat_2 = Input(shape=(4,201,1))

shared_conv = Convolution2D(filters=16,kernel_size=(4,24),padding='valid') #no need to claim input_shape?
#shared_conv_2 = Convolution2D(filters=16,kernel_size=(4,24),padding='valid')
x1 = shared_conv(mat_1)
x2 = shared_conv(mat_2)
x1 = ReLU()(x1)
x2 = ReLU()(x2)
x1_1 = MaxPooling2D(pool_size=(1,178))(x1) #length-filter_length+1
x1_2 = AveragePooling2D(pool_size=(1,178))(x1)
x2_1 = MaxPooling2D(pool_size=(1,178))(x2)
x2_2 = AveragePooling2D(pool_size=(1,178))(x2)
merged_vector = concatenate([x1_1,x1_2,x2_1,x2_2])
#merged_vector = concatenate([x1_1,x1_2])

x = Flatten()(merged_vector)
x = BatchNormalization()(x)
x = Dense(64,activation='relu',kernel_initializer=random_normal(mean=0,stddev=1),bias_initializer=random_normal(mean=0,stddev=1))(x)
#x = Dropout(0.5)(x)
#x = Dense(128,activation='relu',kernel_initializer=random_normal(mean=0,stddev=1),bias_initializer=random_normal(mean=0,stddev=1))(x)
#x = Dropout(0.5)(x)
main_output = Dense(1,activation='sigmoid',kernel_initializer=random_normal(mean=0,stddev=1),bias_initializer=random_normal(mean=0,stddev=1))(x)

model = Model(inputs=[mat_1,mat_2],outputs=main_output)
#model = Model(inputs=mat_1,outputs=main_output)
#model.compile(loss='mse',optimizer='sgd')
model.compile(loss='mse',optimizer='Adam')
early_stopping = EarlyStopping(monitor='val_loss',patience=100)

start = time.time()

#history = model.fit([x_train_1,x_train_2],y_train,batch_size=32,epochs=100,validation_data=[[x_test_1,x_test_2],y_test],callbacks=[early_stopping])

history = model.fit([x_train_1,x_train_2],y_train,batch_size=64,epochs=1000,validation_data=[[x_test_1,x_test_2],y_test],callbacks=[early_stopping])

end = time.time()
dur = end - start
os.system('echo %s %s >> time_rec.txt' % (name,dur))

prob = model.predict([x_train_1,x_train_2])
fpr, tpr, threshold = roc_curve(y_train,prob)
tr_roc_auc = auc(fpr,tpr)

score = model.evaluate([x_test_1,x_test_2],y_test)

import math
from sklearn import metrics

prob = model.predict([x_train_1,x_train_2])

prob = model.predict([x_test_1,x_test_2])

fpr, tpr, threshold = roc_curve(y_test,prob)
val_roc_auc = auc(fpr,tpr)
prc = average_precision_score(y_test,prob)

Mat,Tag = mat2Mat('example/'+in_file+"_test.txt")
x_test_1 = Mat[:,0,:,:]
x_test_1 = x_test_1.reshape(x_test_1.shape[0],x_test_1.shape[2],4)
x_test_1 = pad_sequences(x_test_1, maxlen=201, padding='post')
x_test_1 = x_test_1.reshape(x_test_1.shape[0],4,201,1)
x_test_2 = Mat[:,1,:,:]
x_test_2 = x_test_2.reshape(x_test_2.shape[0],x_test_2.shape[2],4)
x_test_2 = pad_sequences(x_test_2, maxlen=201, padding='post')
x_test_2 = x_test_2.reshape(x_test_2.shape[0],4,201,1)

prob = model.predict([x_test_1,x_test_2])
fpr, tpr, threshold = roc_curve(Tag,prob)
te_roc_auc = auc(fpr,tpr)

TP, FP, TN, FN, TPR, TNR, PPV, NPV, FNR, FPR, FDR, FOR, ACC, F1, MCC, BM, MK = comparison(Tag,prob)
f3 = open("output/"+in_file+"_result.txt",'w')
f3.writelines("data"+"\t"+"TP"+"\t"+"TN"+"\t"+"FN"+"\t"+"FP"+"\t"+"TPR"+"\t"+"TNR"+"\t"+"ACC"+"\t"+"F1"+"\t"+"MCC"+"\t"+"auc"+"\n")
f3.writelines("test"+"\t"+str(TP)+"\t"+str(TN)+"\t"+str(FN)+"\t"+str(FP)+"\t"+str(TPR)+"\t"+str(TNR)+"\t"+str(ACC)+"\t"+str(F1)+"\t"+str(MCC)+"\t"+str(te_roc_auc)+"\n")
f3.close()
model.save('output/%s_model.h5' % name)
