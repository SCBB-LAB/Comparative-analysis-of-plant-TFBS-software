python3 predict.py --start_index 0 --end_index 1 --peak_flank 100 --network CNN --feature_format Seq --start_cutoff 0.01 --end_cutoff 1 --step_cutoff 0.03
sh seq_to_fasta.sh
sh seq_to_pwm.sh

ls ../output/encode_201/gc_match/AT2G28810/Seq/CNN/0/motif*/seq_motif_instances_pwm.txt | sed "s+.txt++" | while read i ; do python3.8 x6.py $i ../output/AT2G28810_pos.fa ../AT2G28810_1 ; done
