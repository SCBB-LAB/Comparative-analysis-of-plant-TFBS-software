import os
os.environ["CUDA_VISIBLE_DEVICES"] = '0'
import torch.optim as optim
import torch.utils.data as loader
import math
from torchsummary import summary

from tqdm import tqdm
from sklearn.metrics import accuracy_score, roc_auc_score, precision_recall_curve, auc, matthews_corrcoef
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from torch.utils.data import random_split
from Datasets.DataReader import Datasets
#from torchmetrics import MatthewsCorrCoef
#from torchmetrics.functional import matthews_corrcoef

from sklearn.metrics import confusion_matrix
import torch
from torch import nn
import numpy as np
import sys

from torchmetrics.classification import BinarySpecificity
from torchmetrics.classification import BinaryMatthewsCorrCoef
from torchmetrics.classification import BinaryF1Score
from torchmetrics.classification import BinaryConfusionMatrix
class Constructor:
    def __init__(self, model, model_name='deepstf'):

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = model.to(device=self.device)
        self.model_name = model_name
        self.optimizer = optim.Adam(self.model.parameters())
#        self.optimizer = optim.Adadelta(self.model.parameters())
        self.scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer=self.optimizer, patience=5, verbose=1)
        self.loss_function = nn.BCELoss()
        self.batch_size = 128
      #  self.batch_size = 64
        self.epochs = 15

    def practise(self, TrainLoader, ValidateLoader):
        path = os.path.abspath(os.curdir)
        for epoch in range(self.epochs):
            self.model.train()
            ProgressBar = tqdm(TrainLoader)
            for data in ProgressBar:
                self.optimizer.zero_grad()
                ProgressBar.set_description("Epoch %d" % epoch)
                seq, shape, label = data
                output= self.model(seq.unsqueeze(1).to(self.device), shape.unsqueeze(1).to(self.device))
                loss = self.loss_function(output, label.float().to(self.device))
                ProgressBar.set_postfix(loss=loss.item())
                loss.backward()
                self.optimizer.step()
            valid_loss = []

            self.model.eval()
            with torch.no_grad():
                for valid_seq, valid_shape, valid_labels in ValidateLoader:
                    valid_output = self.model(valid_seq.unsqueeze(1).to(self.device), valid_shape.unsqueeze(1).to(self.device))
                    valid_labels = valid_labels.float().to(self.device)
                    valid_loss.append(self.loss_function(valid_output, valid_labels).item())
                valid_loss_avg = torch.mean(torch.Tensor(valid_loss))
                self.scheduler.step(valid_loss_avg)
        
        #torch.save(self.model.state_dict(), path + '\\' + self.model_name + '.pth')
        torch.save(self.model.state_dict(), "model/"+sys.argv[1]+"_model.pth")


    def demonstration(self, TestLoader):
        path = os.path.abspath(os.curdir)
        self.model.load_state_dict(torch.load("model/"+sys.argv[1]+"_model.pth", map_location="cpu"))
        #self.model.load_state_dict(torch.load("model.pth", map_location="cpu"))
        
        #self.model.load_state_dict(torch.load(path + '/' + self.model_name + '.pth', map_location='cpu'))
       # self.model.load_state_dict(torch.load(path + '\\' + self.model_name + '.pth', map_location='cpu'))
        #print(path + '\\' + self.model_name + '.pth')
        predict_value = []
        true_label = []
        self.model.eval()
        with torch.no_grad():
            for seq, shape, label in TestLoader:
                output = self.model(seq.unsqueeze(1).to(self.device), shape.unsqueeze(1).to(self.device))
#                valid_labels = valid_labels.float().to(self.device)
                predict_value.append(output.squeeze(dim=0).squeeze(dim=0).detach().cpu().numpy())
                true_label.append(label.squeeze(dim=0).squeeze(dim=0).detach().cpu().numpy())
            return predict_value, true_label

    def estimate(self, predict_value, true_label):
        CM=0
        fw = open('output/'+sys.argv[1]+'_stats.txt', 'w')
        labels_np=np.array(predict_value).round()
        predictions_np=true_label
        confmat = BinaryConfusionMatrix()
        #accuracy = accuracy_score(y_pred=np.array(predict_value).round(), y_true=true_label)
        accuracy = accuracy_score(labels_np, predictions_np)
        roc_auc = roc_auc_score(y_score=predict_value, y_true=true_label)
        precision, recall, _ = precision_recall_curve(probas_pred=predict_value, y_true=true_label)
        pr_auc = auc(recall, precision)
        #y_pred = torch.tensor(predict_value)
        #y_true = torch.tensor(true_label)

        #print(f'\nConfusionMatrix: \n{confmat(y_pred, y_true).cpu().numpy()}') # caculate all the TP, TN, FN, FP
       
        CM+=confusion_matrix(labels_np, predictions_np,labels=[0,1])
        
        tn=CM[0][0]
        tp=CM[1][1]
        fp=CM[0][1]
        fn=CM[1][0]
        f1 = BinaryF1Score()
        mcc = BinaryMatthewsCorrCoef()
        acc=np.sum(np.diag(CM)/np.sum(CM))
        sensitivity=tp/(tp+fn)
        precision=tp/(tp+fp)
        sp=tn/(tn+fp)
        MCC=matthews_corrcoef(labels_np, predictions_np)
        print("mcc",MCC)
        print('- Sensitivity : ',(tp/(tp+fn))*100)
        print('- Specificity : ',(tn/(tn+fp))*100)
        print('- Precision: ',(tp/(tp+fp))*100)
        print('- NPV: ',(tn/(tn+fn))*100)
        print('- F1 : ',((2*sensitivity*precision)/(sensitivity+precision))*100)
        
        f1_score = (((2*sensitivity*precision)/(sensitivity+precision))*100)
        fw.writelines("TP"+"\t"+"TN"+"\t"+"FN"+"\t"+"FP"+"\t"+"TPR"+"\t"+"TNR"+"\t"+"ACC"+"\t"+"F1"+"\t"+"MCC"+"\t"+"auc"+"\n")
        fw.writelines(str(tp)+"\t"+str(tn)+"\t"+str(fn)+"\t"+str(fp)+"\t"+str(sensitivity.item())+"\t"+str(sp.item())+"\t"+str(acc.item())+"\t"+str(f1_score.item())+"\t"+str(MCC.item())+"\t"+str(roc_auc)+"\n")
        fw.close()
        return accuracy, roc_auc, pr_auc

    def implement(self, data_file_name, ratio=0.8):
        Train_Validate_Set = Datasets(data_file_name, False)
        Train_Set, Validate_Set = random_split(dataset=Train_Validate_Set,
                                               lengths=[math.ceil(len(Train_Validate_Set) * ratio),
                                                        len(Train_Validate_Set) -
                                                        math.ceil(len(Train_Validate_Set) * ratio)],
                                               generator=torch.Generator().manual_seed(0))
        TrainLoader = loader.DataLoader(dataset=Train_Set, drop_last=True,
                                        batch_size=self.batch_size, shuffle=True, num_workers=0)
        ValidateLoader = loader.DataLoader(dataset=Validate_Set, drop_last=True,
                                           batch_size=self.batch_size, shuffle=False, num_workers=0)
        TestLoader = loader.DataLoader(dataset=Datasets(data_file_name, True),
                                       batch_size=1, shuffle=False, num_workers=0)
        self.practise(TrainLoader, ValidateLoader)
        predict_value, true_label = self.demonstration(TestLoader)
        accuracy, roc_auc, pr_auc = self.estimate(predict_value, true_label)        
        return accuracy, roc_auc, pr_auc

#from models.DeepSTF import deepstf
import torch
import models.Transformer as TF
import torch.nn as nn
import torch.nn.functional as F

class deepstf(nn.Module):

    def __init__(self):
        super(deepstf, self).__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.convolution_seq_1 = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=128, kernel_size=(4, 16), stride=(1, 1)),
            nn.ReLU(inplace=True),
            nn.BatchNorm2d(num_features=128)
        )
        self.convolution_shape_1 = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=128, kernel_size=(5, 16), stride=(1, 1)),
            nn.ReLU(inplace=True),
            nn.BatchNorm2d(num_features=128)
        )
        self.max_pooling_1 = nn.MaxPool2d(kernel_size=(1, 4), stride=(1, 2))

########Change the shape "201 or 101" as per input sequence length########
        
        self.transformer_shape=TF.Transformer(201,8,8,128,128,0.1) 
        self.lstm = nn.LSTM(92,21,6, bidirectional=True, batch_first=True, dropout=0.2)

########Change the shape "201 or 101" as per input sequence length#############
########These parameters are as per input squence length 101 base pairs########
        
        #self.transformer_shape=TF.Transformer(101,8,8,128,128,0.1)
        #self.lstm = nn.LSTM(42,21,6, bidirectional=True, batch_first=True, dropout=0.2)
        
        self.convolution_seq_2 = nn.Sequential(
            nn.BatchNorm2d(num_features=128),
            nn.ELU(inplace=True),
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=(1, 3), stride=(1, 1))
        )
        self.convolution_shape_2 = nn.Sequential(
            nn.BatchNorm2d(num_features=128),
            nn.ELU(inplace=True),
            nn.Conv2d(in_channels=128, out_channels=128, kernel_size=(1, 3), stride=(1, 1))
        )
        self.output = nn.Sequential(
            nn.AdaptiveMaxPool2d(output_size=(1, 1)),
            nn.Flatten(start_dim=1),
            nn.Linear(in_features=256, out_features=1),
            nn.Sigmoid()
        )
       
    def execute(self, seq, shape):
        shape = shape.float()
        shape = shape.squeeze(1)
        encoder_shape_output = self.transformer_shape(shape)
        encoder_shape_output = encoder_shape_output.unsqueeze(1)
        conv_shape_1 = self.convolution_shape_1(encoder_shape_output)
        pool_shape_1 = self.max_pooling_1(conv_shape_1)
        pool_shape_1 = pool_shape_1.squeeze(2)

        out_shape, _ = self.lstm(pool_shape_1.to(self.device))
        out_shape1 = out_shape.unsqueeze(2)
        conv_shape_2 = self.convolution_shape_2(out_shape1)

        seq = seq.float()
        conv_seq_1 = self.convolution_seq_1(seq.to(self.device)).to(self.device)
        pool_seq_1 = self.max_pooling_1(conv_seq_1)
        conv_seq_2 = self.convolution_seq_2(pool_seq_1)

        # Adjust the size of tensors along dimension 1
        conv_shape_2 = conv_shape_2[:, :, :, :conv_seq_2.size(3)]
        conv_seq_2 = conv_seq_2[:, :, :, :conv_shape_2.size(3)]

        # Concatenate the tensors
        concatenated_tensor = torch.cat((conv_shape_2, conv_seq_2), dim=1)

        return self.output(concatenated_tensor)       

    def forward(self, seq, shape):
        return self.execute(seq, shape)

Train = Constructor(model=deepstf())
how=Train.implement(data_file_name='example/')
print("acc, auc, precision", how)
