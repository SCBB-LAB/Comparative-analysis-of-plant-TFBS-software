ls Datasets/data_plant/Sequence/*/*fa.* | while read i ; do awk '/^>/ {printf("\n%s,\n", $0); next; } { printf("%s,", $0);}' $i | sed 's/.$//' | sed '/^$/d' | sed '/>/d' | sed 's/NA/0.0/g' > $i\_tmp ; done

