awk '/^>/ {printf("\n%s,\n", $0); next; } { printf("%s,", $0);}' data_plant/$1 | sed 's/.$//' | sed '/^$/d' | sed '/>/d' | sed 's/NA/0.0/g' > data_plant/$1_tmp
#printf "%s," {1..159} | sed 's/,$/\n/g' | cat - data_plant/ABF2_pos.fa.MGW_tmp > data_plant/ABF2_pos.fa.MGW_tmp2 # for adding header to the file
