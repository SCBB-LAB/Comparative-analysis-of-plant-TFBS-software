#printf "%s," {1..159} | sed 's/,$/\n/g' | cat - data_plant/.MGW_tmp > data_plant/ABF2_pos.fa.MGW_tmp2

printf "%s," {1..201} | sed 's/,$/\n/g' | cat - Datasets/data_plant/Sequence/test.fa.EP_tmp > Datasets/data_plant/Shape/Test_EP.csv
printf "%s," {1..201} | sed 's/,$/\n/g' | cat - Datasets/data_plant/Sequence/test.fa.HelT_tmp > Datasets/data_plant/Shape/Test_HelT.csv
printf "%s," {1..201} | sed 's/,$/\n/g' | cat - Datasets/data_plant/Sequence/test.fa.MGW_tmp > Datasets/data_plant/Shape/Test_MGW.csv
printf "%s," {1..201} | sed 's/,$/\n/g' | cat - Datasets/data_plant/Sequence/test.fa.ProT_tmp > Datasets/data_plant/Shape/Test_ProT.csv
printf "%s," {1..201} | sed 's/,$/\n/g' | cat - Datasets/data_plant/Sequence/test.fa.Roll_tmp > Datasets/data_plant/Shape/Test_Roll.csv

printf "%s," {1..201} | sed 's/,$/\n/g' | cat - Datasets/data_plant/Sequence/train.fa.EP_tmp > Datasets/data_plant/Shape/Train_EP.csv
printf "%s," {1..201} | sed 's/,$/\n/g' | cat - Datasets/data_plant/Sequence/train.fa.HelT_tmp > Datasets/data_plant/Shape/Train_HelT.csv
printf "%s," {1..201} | sed 's/,$/\n/g' | cat - Datasets/data_plant/Sequence/train.fa.MGW_tmp > Datasets/data_plant/Shape/Train_MGW.csv
printf "%s," {1..201} | sed 's/,$/\n/g' | cat - Datasets/data_plant/Sequence/train.fa.ProT_tmp > Datasets/data_plant/Shape/Train_ProT.csv
printf "%s," {1..201} | sed 's/,$/\n/g' | cat - Datasets/data_plant/Sequence/train.fa.Roll_tmp > Datasets/data_plant/Shape/Train_Roll.csv

#printf "%s," {1..201} | sed 's/,$/\n/g' | cat - Datasets/data_plant/Sequence/test.fa.EP_tmp > Datasets/data_plant/Shape/Test_EP.csv









