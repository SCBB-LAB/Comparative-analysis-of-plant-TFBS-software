v2.6 -- 6/6/2014
Fixed the running-time error when used under Mac OS. (Tianyin)


