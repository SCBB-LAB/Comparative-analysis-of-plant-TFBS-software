#!/usr/bin/env python
# encoding: utf-8

import numpy as np, argparse, sys, h5py
from os.path import join, abspath, dirname, exists
from keras.callbacks import ModelCheckpoint, EarlyStopping
from keras.optimizers import Adadelta
from keras.models import load_model
from sklearn.metrics import roc_auc_score 
from models import DeepBind, DanQ, WSCNNwithNoisy, WSCNNwithMax, WSCNNwithAve, WSCNNLSTMwithNoisy, WSCNNLSTMwithMax, WSCNNLSTMwithAve
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

from utils import *
def comparison(testlabel, resultslabel):
    TP = 0
    FP = 0
    TN = 0
    FN = 0
    for row1 in range(len(resultslabel)):
        if resultslabel[row1] < 0.5:
            resultslabel[row1] = 0
        else:
            resultslabel[row1] = 1
    for row2 in range(len(testlabel)):
        if testlabel[row2] == 1 and testlabel[row2] == resultslabel[row2]:
            TP = TP + 1
        if testlabel[row2] == 0 and testlabel[row2] != resultslabel[row2]:
            FP = FP + 1
        if testlabel[row2] == 0 and testlabel[row2] == resultslabel[row2]:
            TN = TN + 1
        if testlabel[row2] == 1 and testlabel[row2] != resultslabel[row2]:
            FN = FN + 1
    if TP + FN != 0:
        TPR = TP / (TP + FN)
    else:
        TPR = 0
    if TN + FP != 0:
        TNR = TN / (TN + FP)
    else:
        TNR = 0
    if TP + FP != 0:
        PPV = TP / (TP + FP)
    else:
        PPV = 0
    if TN + FN != 0:
        NPV = TN / (TN + FN)
    else:
        NPV = 0
    if FN + TP != 0:
        FNR = FN / (FN + TP)
    else:
        FNR = 0
    if FP + TN != 0:
        FPR = FP / (FP + TN)
    else:
        FPR = 0
    if FP + TP != 0:
        FDR = FP / (FP + TP)
    else:
        FDR = 0
    if FN + TN != 0:
        FOR = FN / (FN + TN)
    else:
        FOR = 0
    if TP + TN + FP + FN != 0:
        ACC = (TP + TN) / (TP + TN + FP + FN)
    else:
        ACC = 0
    if TP + FP + FN != 0:
        F1 = (2 * TP) / (2 * TP + FP + FN)
    else:
        F1 = 0
    if (TP + FP) * (TP + FN) * (TN + FP) * (TN + FN) != 0:
        MCC = (TP * TN + FP * FN) / math.sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))
    else:
        MCC = 0
    if TPR != 0 and TNR != 0:
        BM = TPR + TNR - 1
    else:
        BM = 0
    if PPV != 0 and NPV != 0:
        MK = PPV + NPV - 1
    else:
        MK = 0
    return TP, FP, TN, FN, TPR, TNR, PPV, NPV, FNR, FPR, FDR, FOR, ACC, F1, MCC, BM, MK


def parse_args():
    parser = argparse.ArgumentParser(description="Convert sequence and target")
    parser.add_argument('-datalable', dest='datalable', type=str, help='Positive data for training, testing')
    parser.add_argument('-k', dest='k_folds', type=int, default=3, help='k-folds cross-validation')
    parser.add_argument('-kernelsize', dest='kernelsize', type=int, default=24, help='the kernelsize of convolutional layer')
    parser.add_argument('-batchsize', dest='batchsize', type=int, default=300, help='the size of one batch')
    parser.add_argument('-ratio', dest='ratio', type=float, default=0.125, help='the propotion of validation data over the training data')
    parser.add_argument('-params', dest='params', type=int, default=1, help='the number of paramter settings')
    parser.add_argument('-train', dest='train', action='store_true', default=True, help='only test step')
    parser.add_argument('-plot', dest='plot', action='store_true', default=True, help='only test step')
    parser.add_argument('-run', dest='run', type=str, default='nows', help='three encoding methods, including ws, nows')
    
    return parser.parse_args()



def main():

    file_path = dirname(abspath(__file__))
    args = parse_args()
    
    # print the current dataset name
    name = (args.datalable).split('/')[-2]
    print('working on %s now' % name)
    
    # convert raw data 
    if args.run == 'nows':
       print('using no-ws encoding method.')
       with h5py.File(args.datalable, 'r') as f:
           seqs_vector = np.asarray(f['data'])
           labels = np.asarray(f['label'])
       seqs_num = seqs_vector.shape[0]; seqs_len = seqs_vector.shape[1]
       seqs_dim = seqs_vector.shape[2]
       print('there are %d seqences, each of which is a %d*%d array' %(seqs_num, seqs_len, seqs_dim))
       input_shape = (seqs_len, seqs_dim)
    elif args.run == 'ws':
       print('using ws encoding method.')
       with h5py.File(args.datalable, 'r') as f:
           seqs_vector = np.asarray(f['data'])
           labels = np.asarray(f['label'])
       seqs_num = seqs_vector.shape[0]; instance_num = seqs_vector.shape[1]
       instance_len = seqs_vector.shape[2]; instance_dim = seqs_vector.shape[3]
       print('there are %d seqences, each of which is a %d*%d*%d array' %(seqs_num, instance_num, instance_len, instance_dim))
       input_shape = (instance_num, instance_len, instance_dim)
    else:
       print('invalid command!', file=sys.stderr);sys.exit(1)
    
    # k-folds cross-validation
    indices = np.arange(seqs_num)
    np.random.shuffle(indices)
    seqs_vector = seqs_vector[indices]
    labels = labels[indices]

    train_ids, test_ids, valid_ids = Id_k_folds(seqs_num, args.k_folds, args.ratio)
    print(len(train_ids), len(test_ids), len(valid_ids))
    rocauc = []; prauc = []
    
    space = AllSample()
    if not exists('%s' % name):
       print('Building ' + '%s' % name)
       #os.mkdir('/output/%s' % name)
    f_params = open('%s/params.txt' % name, 'w')

    for fold in range(args.k_folds):
        X_train = seqs_vector[train_ids[fold]] 
        y_train = labels[train_ids[fold]]
        X_test = seqs_vector[test_ids[fold]]
        y_test = labels[test_ids[fold]]
        X_valid = seqs_vector[valid_ids[fold]]
        y_valid = labels[valid_ids[fold]]
        print(len(X_train), len(y_train), len(X_test), len(y_test), len(X_valid), len(y_valid))
       
        if args.train:
           history_all = {}
           for params_num in range(args.params):
               params = space[params_num]
               print("the {}-th paramter setting of the {}-th is {}".format(params_num, fold, params))
               print("the {}-th paramter setting of the {}-th is {}".format(params_num, fold, params), file=f_params)
               print('Building model...')
               if args.run == 'nows':
                  model = DeepBind(input_shape, params)
               else:
                  model = WSCNNLSTMwithNoisy(input_shape, params)
              # checkpointer = ModelCheckpoint(filepath=file_path + '/output/%s/params%d_bestmodel_%dfold.hdf5' 
               checkpointer = ModelCheckpoint(filepath='%s/params%d_bestmodel_%dfold.hdf5' 
                                                % (name, params_num, fold), monitor='val_accuracy', verbose=1, save_best_only=True)
               earlystopper = EarlyStopping(monitor='val_accuracy', patience=6, verbose=1)

               print('Training model...')
               myoptimizer = Adadelta(epsilon=params['DELTA'], rho=params['MOMENT'])
               model.compile(loss='binary_crossentropy', optimizer=myoptimizer, metrics=['accuracy'])
               History = model.fit(X_train, y_train, epochs=60, batch_size=args.batchsize, shuffle=True,
                                   validation_data=(X_valid, y_valid), callbacks=[checkpointer, earlystopper], verbose=2)
          
               history_all[str(params_num)] = History
           #best_num = SelectBest(history_all, file_path + '/output/%s/' % name, fold, 'val_accuracy')
           best_num = SelectBest(history_all, '%s/' % name, fold, 'val_accuracy')
           if args.plot: PlotandSave(history_all[str(best_num)], '%s/figure_%dfold.png' % (name, fold), fold, 'val_accuracy')
           #if args.plot: PlotandSave(history_all[str(best_num)], file_path + '/output/%s/figure_%dfold.png' % (name, fold), fold, 'val_accuracy')
          
        print('Testing model...')
        # load_model('')
        model.load_weights('%s/params%d_bestmodel_%dfold.hdf5' % (name, best_num, fold))
        #model.load_weights(file_path + '/output/%s/params%d_bestmodel_%dfold.hdf5' % (name, best_num, fold))
        results = model.evaluate(X_test, y_test)
        print(results)
        tr_y_pred = model.predict(X_train, batch_size=args.batchsize, verbose=1) #prediction on train dataset
        tr_y_pred = np.asarray([y[0] for y in tr_y_pred])
        tr_y_real = np.asarray([y[0] for y in y_train])
        
        print('Calculating AUC for train dataset...')
        auroc, auprc = ComputeAUC(tr_y_pred, tr_y_real)
        labels2=np.array(tr_y_pred)
        labels2[labels2>=0.5]=1
        labels2[labels2<0.5]=0
        TP, FP, TN, FN, TPR, TNR, PPV, NPV, FNR, FPR, FDR, FOR, ACC, F1, MCC, BM, MK = comparison(labels2, tr_y_real)
       
        outfile = '%s/train_metrics.txt' % (name)
        f = open(outfile,'a+')
        
        f.writelines("TP"+"\t"+"TN"+"\t"+"FN"+"\t"+"FP"+"\t"+"TPR"+"\t"+"TNR"+"\t"+"ACC"+"\t"+"F1"+"\t"+"MCC"+"\t"+"ROC_AUC"+"\t"+"pr_AUC"+"\n")
        f.writelines(str(TP)+"\t"+str(TN)+"\t"+str(FN)+"\t"+str(FP)+"\t"+str(TPR)+"\t"+str(TNR)+"\t"+str(ACC)+"\t"+str(F1)+"\t"+str(MCC)+"\t"+str(np.mean(rocauc))+"\t"+str(np.mean(prauc))+"\n") 
        
        
        y_pred = model.predict(X_test, batch_size=args.batchsize, verbose=1) # prediction on test dataset
        y_pred = np.asarray([y[0] for y in y_pred])
        y_real = np.asarray([y[0] for y in y_test])
        #with open(file_path + '/output/%s/score_%dfold.txt' % (name, fold), 'w') as f:
        with open('%s/score_%dfold.txt' % (name, fold), 'w') as f:
           assert len(y_pred) == len(y_real), 'dismathed!'
           for i in range(len(y_pred)):
               print('{:.5f} {}'.format(y_pred[i], y_real[i]), file=f)

        print('Calculating AUC...')
        auroc, auprc = ComputeAUC(y_pred, y_real)
        rocauc.append(auroc); prauc.append(auprc)
        #print("y_pred",y_pred)
        labels1=np.array(y_pred)
        labels1[labels1>=0.5]=1
        labels1[labels1<0.5]=0
        #print("y_label",labels1)
        
        
        #print("y_real",y_real)
        TP, FP, TN, FN, TPR, TNR, PPV, NPV, FNR, FPR, FDR, FOR, ACC, F1, MCC, BM, MK = comparison(labels1, y_real)
        
        #outfile = file_path + '/output/%s_result.txt' % (name)
        outfile = '%s/result.txt' % (name)
        f = open(outfile,'a+')
        
        f.writelines("TP"+"\t"+"TN"+"\t"+"FN"+"\t"+"FP"+"\t"+"TPR"+"\t"+"TNR"+"\t"+"ACC"+"\t"+"F1"+"\t"+"MCC"+"\t"+"ROC_AUC"+"\t"+"pr_AUC"+"\n")
        f.writelines(str(TP)+"\t"+str(TN)+"\t"+str(FN)+"\t"+str(FP)+"\t"+str(TPR)+"\t"+str(TNR)+"\t"+str(ACC)+"\t"+str(F1)+"\t"+str(MCC)+"\t"+str(np.mean(rocauc))+"\t"+str(np.mean(prauc))+"\n") 
        
    f_params.close()
    print("the average rocauc is {} and the average prauc is {}".format(np.mean(rocauc), np.mean(prauc)))


if __name__ == '__main__': main()     
