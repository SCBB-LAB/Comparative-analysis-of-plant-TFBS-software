This file is a tutorial for the docker image of tsptfbs.
